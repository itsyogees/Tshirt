import React from 'react'
import LoginPage from './pages/Login/login'
 
const page = () => {
  return (
    <div><LoginPage/>
 
    </div>
  )
}

export default page